﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Unit_Converter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MassClicked(object sender, RoutedEventArgs e)
        {
            var newMassWindow = new Window1();
            newMassWindow.Show();
        }

        private void TempClicked(object sender, RoutedEventArgs e)
        {
            var newTempWindow = new Window2();
            newTempWindow.Show();
        }

        private void VolClicked(object sender, RoutedEventArgs e)
        {

        }
    }
}
