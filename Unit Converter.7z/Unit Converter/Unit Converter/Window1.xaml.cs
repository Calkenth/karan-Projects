﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Unit_Converter
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            double kglb = 2.2046226;
            //double lbkg = 0.45359237;
            string input = UserNum.Text;
            double inputNum = Convert.ToDouble(input);
            double output = inputNum;
            
            if (comboBox.SelectedItem == kg && outputBox.SelectedItem == olb)
            {
                output = kglb * inputNum;;
            }
            if (comboBox.SelectedItem == lb && outputBox.SelectedItem == okg)
            {
                output = (1/kglb) * inputNum;
            }
            if( comboBox.SelectedItem == g && outputBox.SelectedItem == omg || comboBox.SelectedItem == kg && outputBox.SelectedItem == og)
            {
                Upp upp = new Upp();
                output = upp.Thousand(inputNum);
            }
            if (comboBox.SelectedItem == kg && outputBox.SelectedItem == omg)
            {
                Upp upp = new Upp();
                output = upp.Million(inputNum);
            }
            if (comboBox.SelectedItem == g && outputBox.SelectedItem == okg || comboBox.SelectedItem == mg && outputBox.SelectedItem == og)
            {
                Down down = new Down();
                output = down.Thousand(inputNum);
            }
            if (comboBox.SelectedItem == mg && outputBox.SelectedItem == okg)
            {
                Down down = new Down();
                output = down.Million(inputNum);
            }

            label2.Content = Convert.ToString(output);
        }
    }

    public class Upp
    {
        double x;
        public double Thousand(double x)
        {
            x = x * 1000;
            return x;
        }
        public double Million(double x)
        {
            x = x * 1000000;
            return x;
        }
    }
    public class Down
    {
        double x;
        public double Thousand(double x)
        {
            x = x / 1000;
            return x;
        }
        public double Million(double x)
        {
            x = x / 1000000;
            return x;
        }
    }
}
