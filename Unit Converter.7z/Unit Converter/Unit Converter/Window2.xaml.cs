﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Unit_Converter
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();            
        }

        public void TempUnitSel(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                double input = Convert.ToDouble(UserNum.Text);
            
            if(comboTemp.SelectedItem == C)
            {
                Clabel.Content = UserNum.Text + " C";
                Celcius celcius = new Celcius();
                Flabel.Content = Convert.ToString(celcius.getF(input)) + " F";
                Klabel.Content = Convert.ToString(celcius.getK(input)) + " K";
            }
            if (comboTemp.SelectedItem == K)
            {
                Klabel.Content = UserNum.Text + " K";
                Kelvin kelvin = new Kelvin();
                Flabel.Content = Convert.ToString(kelvin.getF(input)) + " F";
                Clabel.Content = Convert.ToString(kelvin.getC(input)) + " C";
            }
            if (comboTemp.SelectedItem == F)
            {
                Flabel.Content = UserNum.Text + " F";
                Fahrenheit fahrenheit = new Fahrenheit();
                Klabel.Content = Convert.ToString(fahrenheit.getK(input)) + " K";
                Clabel.Content = Convert.ToString(fahrenheit.getC(input)) + " C";
            }
            }
            catch (FormatException)
            {
                MessageBox.Show("Program will be shut down.\nNext time put a VALUE into it's place.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Process.Start(Application.ResourceAssembly.Location); //------ IT RESTART ALL WPF APP(or more likely run another one)
                Application.Current.Shutdown();
            }
        }
    }
    public class Celcius
    {
        double K, F;
        public double getK(double C)
        {
            K = C - 257.15;
            return K;
        }
        public double getF(double C)
        {
            F = (C * 1.8) + 32;
            return F;
        }
    }
    public class Kelvin
    {
        double C, F;
        public double getC(double K)
        {
            C = K + 257.15;
            return C;
        }
        public double getF(double K)
        {
            F = (K* (9/5))-459.67;
            return F;
        }
    }
    public class Fahrenheit
    {
        double K, C;
        public double getK(double F)
        {
            K = 60*F + 459.67;
            K = K * 5 / 9;
            return K;
        }
        public double getC(double F)
        {
            C = (F -32)/1.8;
            return C;
        }
    }
}
