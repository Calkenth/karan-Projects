﻿using System;
using System.Media;
using System.Collections.Generic;
using System.Timers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Alarm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        bool SoundIsOn;
        SoundPlayer player = new SoundPlayer();
        string H, Min, total;
        DispatcherTimer aTimer = new DispatcherTimer();
        string time = "";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TimeSet(object sender, RoutedEventArgs e)
        {
            int numH = -1;
            int numMin = -1;
            H = InputH.Text;
            Min = InputMin.Text;
            try
            {
                numH = Convert.ToInt16(H);
                numMin = Convert.ToInt16(Min);

                if (numH < 0 || numH > 24)
                {
                    MessageBox.Show("There is no hour like that.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (numMin < 0 || numMin > 60)
                {
                    MessageBox.Show("There is no minute like that.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                    total = H + ":" + Min + ":00";
            }
            catch(FormatException)
            {
                MessageBox.Show("Put integer value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);//Reloading new app, or
                Application.Current.Shutdown();                                         //more like running new just before shuting this one
            }
        }

        private void MusicStop(object sender, RoutedEventArgs e)
        {
            player.Stop();
            total = "";
            SoundIsOn = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string music = @"C:\Users\Plucio\Music\The Offspring - The Kids Arent Alright.wav";
            player.SoundLocation = music;
            player.Load();
            aTimer.Interval = TimeSpan.FromSeconds(1);
            aTimer.Tick += aTimer_Tick;
            aTimer.Start();
        }

        private void aTimer_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            time = dateTime.ToString("HH:mm:ss");
            Time.Content = time;

            if(time == total && SoundIsOn == false)
            {
                player.Play();
                SoundIsOn = true;
            }
        }
    }
}
